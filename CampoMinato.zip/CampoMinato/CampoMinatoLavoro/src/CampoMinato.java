//campo minato virtuale, senz parte virtuale
public class CampoMinato {
    protected Casella[][] campo;
    protected int dimensione; //numero righe e colonne, dimensione del campo
    protected int numBombe; //numero bombe
    public CampoMinato(int dimensione) {
        this.dimensione = dimensione;
        if(this.dimensione<8 || this.dimensione > 30) this.dimensione = 12;
        
        campo = new Casella[dimensione][dimensione];
        for (int i = 0; i < dimensione; i++) {
            for (int j = 0; j < dimensione; j++) {
                if(j < dimensione || i < dimensione){
                    campo[i][j] = new Casella();
                    double s = Math.random() * 100;
                    if(s <= 15.87){
                        campo[i][j].setBomb(true);
                        numBombe++;
                    }
                }                
            }
        }
    }

    public void inizioClick(int x, int y){
        // Se il click iniziale colpisce una bomba, sposta la bomba in un'altra casella
        for (int i = x -1; i <= x + 1; i++) {
            for (int j = y -1; j <= y + 1; j++) {
                campo[i][j].setBomb(false);
                campo[i][j].setBombeVicine(0);
                svelaCasella(i, j);
            }
        }
    }

    public void svelaCasella(int x, int y) {
        if (campo[x][y].isHide()) {
            campo[x][y].scopri();
            contaBombeVicino(x, y);
            if (campo[x][y].getBombeVicine() == 0) {
                if(!campo[x][y].isBomb()) {
                    for (int i = x - 1; i <= x + 1; i++) {
                        for (int j = y - 1; j <= y + 1; j++) {
                            if (!(i == x && j == y) && (!campo[i][j].isBomb()) && campo[i][j].isHide()) {
                                svelaCasella(i, j);
                            }
                        }
                    }
                }
            }
        }
    }

    public void changeBandiera(int x, int y){
        if(campo[x][y].isHide() && campo[x][y].isFlag()) campo[x][y].setFlag(false);
        else if(campo[x][y].isHide()) campo[x][y].setFlag(true);
    }
    public Casella getCasella(int x , int y){
        return this.campo[x][y];
    }    
    
    public int getDimensione(){
        return this.dimensione;
    }
    public int getBombe(){
        return this.numBombe;
    }
    public void contaBombeVicino(int x, int y) {
        if(x < 0 || x >= dimensione || y < 0 || y >= dimensione){
            return;
        }
        int mine = 0;

        mine += contaMina(x-1, y-1);
        mine += contaMina(x-1, y);
        mine += contaMina(x-1, y+1);

        mine += contaMina(x, y-1);
        mine += contaMina(x, y+1);

        mine += contaMina(x+1, y-1);
        mine += contaMina(x+1, y);
        mine += contaMina(x+1, y+1);

        campo[x][y].setBombeVicine(mine);
    }

    public int contaMina(int x, int y){
        if (x >= 0 && x < dimensione && y >= 0 && y < dimensione) {
            if(campo[x][y].isBomb()) return 1;
            else return 0;
        }
        return 0;
    }

    public boolean campoFinito(){
        for (int i = 0; i < dimensione; i++) {
            for (int j = 0; j < dimensione; j++) {
                if(!(campo[i][j].isHide() && campo[i][j].isBomb() && campo[i][j].isFlag()) || !(campo[i][j].isHide() && campo[i][j].isBomb())){
                    return false;
                }
            }
        }
        return true;
    }
    public void setDimensione(int d){
        this.dimensione = d;
    }

    public void svelaCampo(){
        for (int i = 0; i < campo.length; i++) {
            for (int j = 0; j < campo.length; j++) {
                if(campo[i][j].isHide()){
                    campo[i][j].scopri();
                }
            }
        }
    }

    @Override
    public String toString() {
        for (int i = 0; i < dimensione; i++){
            for (int j = 0; j < dimensione; j++) {
                System.out.print(campo[i][j].toString() + " ");
            }
            System.out.println();
        }
        return "";
    }
}