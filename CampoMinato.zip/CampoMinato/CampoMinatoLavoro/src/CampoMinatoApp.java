public class CampoMinatoApp {
    public static void main(String[] args) {
        new MainView();
    }
}
    