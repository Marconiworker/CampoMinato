/*
*model
 */
import java.util.Scanner;

public class MainModel {

    public static int contatore = 0;
    public static boolean giocofinito;
    private static CampoMinato campo;
    private static boolean clickIniziale = false;

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        try{
        
            System.out.println("INSERISCI DIMENSIONE");
            int dimensioneS = Integer.parseInt(s.nextLine());
            campo = new CampoMinato(dimensioneS);
            giocofinito = gioco(campo);
        
        }catch(NumberFormatException e){
            System.out.println("inserisci la dimensiose corretta");
            campo.setDimensione(12);
        }
        
        
        
        if (!(giocofinito)) {
            clickIniziale = false;
            giocaAncora(true);
        } else {
            giocaAncora(false);
        }
    }

    private static boolean gioco(CampoMinato campo) {
        Scanner s = new Scanner(System.in);
        if (contatore == (campo.getDimensione() * campo.getDimensione()) - campo.getBombe()) {
            contatore = 0;
            return false;
        }
        System.out.println(campo);
        System.out.println("F = mettere Flag , X = liberare casella nascosta , T = tasto centrale mouse(per vedere le possibilità di casella) IL METODO CHE DEVI SCRIVERE è COSI -F x y- ");
        String risposta = s.nextLine();
        int x, y;
        try {
            String[] r2 = risposta.split(" ");
            x = Integer.parseInt(r2[1]);
            y = Integer.parseInt(r2[2]);
            switch(r2[0].charAt(0)){
                case 'F' , 'f' ->{
                    campo.changeBandiera(x, y);
                }
                case 'X' , 'x' ->{
                    if(clickIniziale == false){
                        clickIniziale = true;
                        campo.inizioClick(x,y);
                    }else{
                        campo.svelaCasella(x, y);
                        if(campo.getCasella(x,y).isBomb()){
                            return true;
                        }
                    }
                    contatore++;
                }
                case 'T' , 't' -> {
                    //non fa nulla
                }
                default->{
                
                }
            }
        }catch (NumberFormatException e) {
            System.out.println("Scrivi bene la posizione");
            gioco(campo);
        }catch (IndexOutOfBoundsException e) {
            System.out.println("scrivi bene la posizione in modo corretto");
        }
        gioco(campo);
        return false;
    }
    private static void giocaAncora(boolean vittoria) {
        Scanner s = new Scanner(System.in);
        if (vittoria) {
            campo.svelaCampo();
            System.out.println(campo);
            System.out.println("hai perso!");
        }else{
            System.out.println("hai vinto!");
        }
            System.out.println("un altra partita? S / N");
            String risposta = s.nextLine();
            switch (risposta) {
                case "S", "s" -> {
                    System.out.println("INSERISCI DIMENSIONE");
                    int dimensioneS = Integer.parseInt(s.nextLine());
                    CampoMinato campo = new CampoMinato(dimensioneS);
                    gioco(campo);
                            
                        }
                case "F", "f" -> {
                    break;
                }
            }   
    }
}
