
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;

public class MainView {
    static boolean clickIniziale = false;
    private class CasellaMainView extends JButton {
        int r;
        int c;
        boolean bomba;

        public CasellaMainView(int r, int c) {
            this.r = r;
            this.c = c;
            this.bomba = false;
        }
    }
    private CampoMinato campo = new CampoMinato(12); // Inizializzazione con dimensione 8
    // Rimani nella stessa classe
    
    int dimensioneCasella = 80;
    int numRighe = campo.getDimensione();
    int numColonne = numRighe;
    int larghezzaTabellone = numColonne * dimensioneCasella;
    int altezzaTabellone = numRighe * dimensioneCasella;
    
    JFrame frame = new JFrame("Campo Minato");
    JLabel etichettaTesto = new JLabel();
    JPanel pannelloTabellone = new JPanel();

    int conteggioMine = 10;
    CasellaMainView[][] tabellone = new CasellaMainView[numRighe][numColonne];
    ArrayList<CasellaMainView> listaMine;
    Random random = new Random();

    int caselleCliccate = 0;
    boolean partitaFinita = false;

    MainView() {
        frame.setSize(larghezzaTabellone, altezzaTabellone);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        etichettaTesto.setFont(new Font("Arial", Font.BOLD, 25));
        etichettaTesto.setHorizontalAlignment(JLabel.CENTER);
        etichettaTesto.setText("Campo Minato: " + Integer.toString(conteggioMine));

        pannelloTabellone.setLayout(new GridLayout(numRighe, numColonne));
        frame.add(pannelloTabellone);

        for (int r = 0; r < numRighe; r++) {
            for (int c = 0; c < numColonne; c++) {
                CasellaMainView casella = new CasellaMainView(r, c);
                tabellone[r][c] = casella;

                casella.setFocusable(false);
                casella.setMargin(new Insets(0, 0, 0, 0));
                casella.setFont(new Font("Arial Unicode MS", Font.PLAIN, 45));
                casella.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        if (partitaFinita) {
                            return;
                        }
                        CasellaMainView casella = (CasellaMainView) e.getSource();

                        // clic sinistro
                        if (e.getButton() == MouseEvent.BUTTON1) {
                            inizioClic(casella.r, casella.c);
                        }
                        // clic destro
                        else if (e.getButton() == MouseEvent.BUTTON3) {
                            cambioBandiera(casella.r, casella.c);
                        }
                    } 
                });

                pannelloTabellone.add(casella);
            }
        }

        frame.setVisible(true);
        impostaMine();
    }

    void inizioClic(int x, int y) {
        if(clickIniziale){
            scopriCasella(x, y);
        } else {
            campo.inizioClick(x, y); 
            clickIniziale = true; // Imposta il flag del primo clic a true dopo il primo clic iniziale.
        }

        aggiornaTabellone(); // Aggiorna il tabellone dopo ogni azione.
    }

    void scopriCasella(int x, int y) {
        campo.svelaCasella(x, y);
        if(campo.getCasella(x, y).isBomb()){
            rivelareCampo();
        }else{
            aggiornaTabellone();         
        }

    }

    void cambioBandiera(int x, int y) {
        campo.changeBandiera(x, y); 
        aggiornaTabellone(); 
    }


    void impostaDimensione(int d) {
        campo.setDimensione(d); 
        numRighe = campo.getDimensione(); // Aggiorna il numero di righe e colonne dopo aver impostato la dimensione.
        numColonne = numRighe;
        larghezzaTabellone = numColonne * dimensioneCasella;
        altezzaTabellone = numRighe * dimensioneCasella;
        aggiornaTabellone(); 
    }


    void rivelareCampo() {
        campo.svelaCampo(); 
        aggiornaTabellone(); 
    }

    int getDimensione() {
        return campo.getDimensione(); // Utilizza il metodo getDimensione di CampoMinato per ottenere la dimensione del campo
    }
    
    void aggiornaTabellone() {
        for (int r = 0; r < numRighe; r++) {
            for (int c = 0; c < numColonne; c++) {
                CasellaMainView casella = tabellone[r][c];
                casella.setText(campo.getCasella(r, c)+""); // Aggiorna il testo delle caselle sulla base dello stato attuale del campo , chiamando il toString();
            }
        }
        if (campo.campoFinito()) {
            rivelareCampo(); // Se la partita è finita, rivela tutte le mine.
            partitaFinita = true;
        }
    }

    void impostaMine() {
        listaMine = new ArrayList<>();

        int mineRimanenti = conteggioMine;
        while (mineRimanenti > 0) {
            int r = (int)Math.random()*numRighe;
            int c = (int)Math.random()*numColonne;

            CasellaMainView casella = tabellone[r][c]; 
            if (!casella.bomba) {
                casella.bomba = true;
                mineRimanenti--;
            }
        }
    }
}


